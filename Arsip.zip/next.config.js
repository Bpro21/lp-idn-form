/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    // Abaikan error typescript saat build agar proses upload lancar
    ignoreBuildErrors: true,
  },
  eslint: {
    // Abaikan error eslint saat build
    ignoreDuringBuilds: true,
  },
  // Matikan fitur static optimization yang kadang bikin blank di cloud tertentu
  output: 'standalone',
};

export default nextConfig;
